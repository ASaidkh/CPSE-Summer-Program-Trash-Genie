# trashgenie > 2023-08-10 11:50am
https://universe.roboflow.com/cleancan-garbagedetection/trashgenie

Provided by a Roboflow user
License: CC BY 4.0

